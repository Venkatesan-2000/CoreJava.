package day7;

public class DivBy3 {
	public static void main(String[] args) {
		int count=0;
		for(int i=1;i<=30;i++) {
			if(i%3==0) {
				count+=i;
			}
		}
		System.out.println(count);
	}

}
