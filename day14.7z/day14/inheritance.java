package dayy14;
class animal{
	public void display() {
		System.out.println("animal sound");
	}
}
class dog extends animal{
	public void display() {
		System.out.println("woof woof");
	}
}

public class inheritance {
	public static void main(String[] args) {
		animal a=new animal();
		a.display();
		
		dog d=new dog();
		d.display();
	}

}
