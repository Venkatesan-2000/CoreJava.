package dayy14;
class Vechicle{
	public void StartEngine() {
		System.out.println("vechicle engine started...");
	}
}
class Car extends Vechicle{
	public void Drive() {
		System.out.println("car is driving...");
	}
}
class ElectricCar extends Car{
	public void chargeBattery() {
		System.out.println("electric car is charging...");
	}
}
class Bike extends Vechicle{
	public void kickStart() {
		System.out.println("bike is kick-started...");
	}
}
public class vechicleMangementSystem {
	public static void main(String[] args) {
		Vechicle carEngine=new Vechicle();
		carEngine.StartEngine();
		Car newCar=new Car();
		newCar.Drive();
		ElectricCar ev=new ElectricCar();
		ev.chargeBattery();
		Bike bk=new Bike();
		bk.StartEngine();
		bk.kickStart();
	}

}
