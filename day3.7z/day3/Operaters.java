package day1;

public class Operaters {

	public static void main(String[] args) {
		int num=77898766;
		int count=0;
		
		while(num>0) {
			++count;
		num=num/10;
		}	
		System.out.println(count);
	
	
	}
	}

		