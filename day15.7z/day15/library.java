package dayy15;

public class library {
	private int id;
	private String bookName;
	private String authorName;
	private int price;
	
	library(){
		
	}
	library(int id,String bookName,String authorName,int price){
		this.id=id;
		this.bookName=bookName;
		this.authorName=authorName;
		this.price=price;
	}
	public String toString() {
		return "Id : "+ id +"\nbookname : "+ bookName +"\nauthorname : " + authorName +"\nprice : "+ price;
	}

}
