package dayy15;

public class TestClass{
	public static void main(String[] args) {
		Dog d=new Dog();
		d.speak();
		d.move();
		Bird b=new Bird();
		b.speak();
		b.move();
		System.out.println(AnimalInterface.isMammal("dog"));
		System.out.println(AnimalInterface.isMammal("mama"));
		System.out.println(AnimalInterface.category);
	}

}
