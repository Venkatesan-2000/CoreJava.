package dayy15;
abstract class calculator{
	abstract void add();
	abstract void sub();
	public void mul(int a,int b) {
		System.out.println("mul:"+(a*b));
	}
	
}
public class AbstractionEx extends calculator {
	public void add() {
		System.out.println("add:"+(10+20));
	}
	public void sub() {
		System.out.println("sub:"+(30-20));
	}
	public static void main(String[] args) {
		AbstractionEx na=new AbstractionEx();
		na.add();
		na.sub();
		na.mul(10, 20);
	}

}
