package dayy15;

public class Bird implements AnimalInterface {

	@Override
	public void move() {
		System.out.println("the birds flies in the sky");
		
	}
	public void speak() {
		System.out.println("the birds says: chrip chrip!");
	}
	

}
