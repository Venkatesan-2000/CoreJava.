package dayy15;

public class Dog implements AnimalInterface {

	@Override
	public void move() {
		System.out.println("the dog runs on four legs");
		
	}
	public void speak() {
		System.out.println("woof woof");
	}

}
