package dayy15;

public  interface AnimalInterface {
	public final static String category="Living being";
	static boolean isMammal(String animalName) {
		return animalName == "dog" || animalName== "cat" || animalName =="human";
	}
	default void speak() {
		System.out.println("animal is making a sound");
	}
	abstract void move();
	

}
