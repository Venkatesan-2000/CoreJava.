package dayy12;

public class IndianBank {
	private int id;
	String name="gokul";
	int accountno =123456789;
	private int pin;
	float balance =3000;
	
	//getters
	public int getid() {
		return id;
	}
	
	public int getpin() {
		return pin;
	}
	
	//setters
	public void setid (int newid) {
		this.id=newid;
	}
	
	public void setpin(int newpin) {
		this.pin=newpin;
	}
	

}
